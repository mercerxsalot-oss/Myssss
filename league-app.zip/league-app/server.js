require('dotenv').config();
const express = require('express');
const session = require('express-session');
const axios = require('axios');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Session setup
app.use(session({
  secret: process.env.SESSION_SECRET || 'supersecret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 7 * 24 * 60 * 60 * 1000 } // 7 days
}));

// In-memory database (replace with a real DB like MongoDB/SQLite for production)
const db = {
  users: [
    {
      id: 'admin_iysox',
      discordId: null,
      username: 'iysox',
      password: 'kopalopa66',
      avatar: null,
      role: 'admin',
      email: 'admin@league.com'
    }
  ],
  teams: [],
  groups: [],
  fixtures: [],
  players: [],
  settings: {
    name: 'League Manager',
    season: 'Season 2024/25',
    win: 3,
    draw: 1,
    accent: '#3b82f6',
    logo: null,
    banner: null
  },
  log: []
};

function addLog(msg) {
  db.log.unshift({ msg, time: new Date().toLocaleString() });
  if (db.log.length > 50) db.log.pop();
}

// ==================== AUTH MIDDLEWARE ====================
function requireLogin(req, res, next) {
  if (req.session.userId) return next();
  res.status(401).json({ error: 'Not logged in' });
}
function requireAdmin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  const user = db.users.find(u => u.id === req.session.userId);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Not admin' });
  next();
}

// ==================== DISCORD OAUTH ====================

// Step 1: Redirect user to Discord login
app.get('/auth/discord', (req, res) => {
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DISCORD_REDIRECT_URI,
    response_type: 'code',
    scope: 'identify email'
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params}`);
});

// Step 2: Discord redirects back here with a code
app.get('/auth/discord/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect('/?error=no_code');

  try {
    // Exchange code for access token
    const tokenRes = await axios.post(
      'https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: process.env.DISCORD_REDIRECT_URI
      }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
    );

    const { access_token } = tokenRes.data;

    // Get Discord user info
    const userRes = await axios.get('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${access_token}` }
    });

    const discordUser = userRes.data;
    const avatarUrl = discordUser.avatar
      ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png?size=256`
      : `https://cdn.discordapp.com/embed/avatars/${parseInt(discordUser.discriminator || 0) % 5}.png`;

    // Find or create user
    let user = db.users.find(u => u.discordId === discordUser.id);
    if (!user) {
      // Check if username matches existing admin
      const existingAdmin = db.users.find(u => u.username === discordUser.username && u.role === 'admin');
      if (existingAdmin) {
        existingAdmin.discordId = discordUser.id;
        existingAdmin.avatar = avatarUrl;
        existingAdmin.email = discordUser.email || existingAdmin.email;
        user = existingAdmin;
      } else {
        user = {
          id: 'discord_' + discordUser.id,
          discordId: discordUser.id,
          username: discordUser.global_name || discordUser.username,
          avatar: avatarUrl,
          email: discordUser.email,
          role: 'viewer'
        };
        db.users.push(user);
        addLog('New user registered via Discord: ' + user.username);
      }
    } else {
      // Update avatar on every login
      user.avatar = avatarUrl;
      user.username = discordUser.global_name || discordUser.username;
    }

    req.session.userId = user.id;
    res.redirect('/');
  } catch (err) {
    console.error('Discord OAuth error:', err.response?.data || err.message);
    res.redirect('/?error=auth_failed');
  }
});

// Traditional login (for admin iysox)
app.post('/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  req.session.userId = user.id;
  res.json({ user: safeUser(user) });
});

// Logout
app.post('/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});

// Get current user
app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = db.users.find(u => u.id === req.session.userId);
  res.json({ user: user ? safeUser(user) : null });
});

function safeUser(u) {
  return { id: u.id, username: u.username, avatar: u.avatar, role: u.role, email: u.email };
}

// ==================== SETTINGS ====================
app.get('/api/settings', (req, res) => res.json(db.settings));

app.post('/api/settings', requireAdmin, (req, res) => {
  Object.assign(db.settings, req.body);
  addLog('Settings updated');
  res.json(db.settings);
});

// ==================== TEAMS ====================
app.get('/api/teams', (req, res) => res.json(db.teams));

app.post('/api/teams', requireAdmin, (req, res) => {
  const team = { id: 't' + Date.now(), played:0,won:0,drawn:0,lost:0,gf:0,ga:0,pts:0,form:[], ...req.body };
  db.teams.push(team);
  addLog('Added team: ' + team.name);
  res.json(team);
});

app.put('/api/teams/:id', requireAdmin, (req, res) => {
  const i = db.teams.findIndex(t => t.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Not found' });
  db.teams[i] = { ...db.teams[i], ...req.body };
  addLog('Edited team: ' + db.teams[i].name);
  res.json(db.teams[i]);
});

app.delete('/api/teams/:id', requireAdmin, (req, res) => {
  const t = db.teams.find(t => t.id === req.params.id);
  db.teams = db.teams.filter(t => t.id !== req.params.id);
  db.fixtures = db.fixtures.filter(f => f.home !== req.params.id && f.away !== req.params.id);
  addLog('Deleted team: ' + t?.name);
  res.json({ ok: true });
});

// ==================== GROUPS ====================
app.get('/api/groups', (req, res) => res.json(db.groups));

app.post('/api/groups', requireAdmin, (req, res) => {
  const group = { id: 'g' + Date.now(), ...req.body };
  db.groups.push(group);
  addLog('Added group: ' + group.name);
  res.json(group);
});

app.delete('/api/groups/:id', requireAdmin, (req, res) => {
  const g = db.groups.find(g => g.id === req.params.id);
  db.groups = db.groups.filter(g => g.id !== req.params.id);
  db.teams.forEach(t => { if (t.group === req.params.id) t.group = ''; });
  addLog('Deleted group: ' + g?.name);
  res.json({ ok: true });
});

// ==================== FIXTURES ====================
app.get('/api/fixtures', (req, res) => res.json(db.fixtures));

app.post('/api/fixtures', requireAdmin, (req, res) => {
  const fx = { id: 'f' + Date.now(), ...req.body };
  db.fixtures.push(fx);
  if (fx.status === 'played' || fx.status === 'live') applyStats(fx);
  recalc();
  addLog('Added fixture');
  res.json(fx);
});

app.put('/api/fixtures/:id', requireAdmin, (req, res) => {
  const i = db.fixtures.findIndex(f => f.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Not found' });
  const old = db.fixtures[i];
  if (old.status === 'played' || old.status === 'live') reverseStats(old);
  db.fixtures[i] = { ...old, ...req.body };
  if (db.fixtures[i].status === 'played' || db.fixtures[i].status === 'live') applyStats(db.fixtures[i]);
  recalc();
  res.json(db.fixtures[i]);
});

app.delete('/api/fixtures/:id', requireAdmin, (req, res) => {
  const f = db.fixtures.find(f => f.id === req.params.id);
  if (f && (f.status === 'played' || f.status === 'live')) reverseStats(f);
  db.fixtures = db.fixtures.filter(f => f.id !== req.params.id);
  recalc();
  res.json({ ok: true });
});

// ==================== PLAYERS ====================
app.get('/api/players', (req, res) => res.json(db.players));

app.post('/api/players', requireAdmin, (req, res) => {
  const p = { id: 'p' + Date.now(), ...req.body };
  db.players.push(p);
  addLog('Added player: ' + p.name);
  res.json(p);
});

app.put('/api/players/:id', requireAdmin, (req, res) => {
  const i = db.players.findIndex(p => p.id === req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Not found' });
  db.players[i] = { ...db.players[i], ...req.body };
  res.json(db.players[i]);
});

app.delete('/api/players/:id', requireAdmin, (req, res) => {
  db.players = db.players.filter(p => p.id !== req.params.id);
  res.json({ ok: true });
});

// ==================== LOG ====================
app.get('/api/log', requireAdmin, (req, res) => res.json(db.log));

// ==================== STATS HELPERS ====================
function reverseStats(f) {
  const h = db.teams.find(t => t.id === f.home);
  const a = db.teams.find(t => t.id === f.away);
  if (!h || !a) return;
  h.played--; a.played--;
  h.gf -= f.hs; h.ga -= f.as;
  a.gf -= f.as; a.ga -= f.hs;
  if (f.hs > f.as) { h.won--; a.lost--; h.pts -= db.settings.win; }
  else if (f.hs < f.as) { a.won--; h.lost--; a.pts -= db.settings.win; }
  else { h.drawn--; a.drawn--; h.pts -= db.settings.draw; a.pts -= db.settings.draw; }
}

function applyStats(f) {
  const h = db.teams.find(t => t.id === f.home);
  const a = db.teams.find(t => t.id === f.away);
  if (!h || !a) return;
  h.played++; a.played++;
  h.gf += f.hs; h.ga += f.as;
  a.gf += f.as; a.ga += f.hs;
  h.form = [...(h.form || []).slice(-4), f.hs > f.as ? 'W' : f.hs === f.as ? 'D' : 'L'];
  a.form = [...(a.form || []).slice(-4), f.as > f.hs ? 'W' : f.hs === f.as ? 'D' : 'L'];
  if (f.hs > f.as) { h.won++; a.lost++; h.pts += db.settings.win; }
  else if (f.hs < f.as) { a.won++; h.lost++; a.pts += db.settings.win; }
  else { h.drawn++; a.drawn++; h.pts += db.settings.draw; a.pts += db.settings.draw; }
}

function recalc() {
  db.teams.forEach(t => { t.played=0;t.won=0;t.drawn=0;t.lost=0;t.gf=0;t.ga=0;t.pts=0;t.form=[]; });
  db.fixtures.filter(f => f.status === 'played' || f.status === 'live').forEach(applyStats);
}

// ==================== START ====================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`League Manager running on http://localhost:${PORT}`);
  console.log(`Discord Client ID: ${process.env.DISCORD_CLIENT_ID}`);
});
